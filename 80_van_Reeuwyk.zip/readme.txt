User login information:
Registration does work, but log into below accounts to view already populated data schenarious
Main user is  Douglas@gmail.com 

Douglas@gmail.com Douglas12! (Admin)


Arno@gmail.com	Arno6312! (User)
john@gmail.com  Awesome6312! (User)
Oats@gmail.com DEmrEjdRt7Mqbmh12! (User)
Alicia@gmail.com Alicica1234! (Admin)
Ronald@gmail.com Ronald876! (User)
Darius@gmail.com Darius!654! (User)
Email@gmail.com	Emil9112! (Admin)
Sam@gmail.com	Sam6312! (User)

please refer to the excel spreadsheet for comments

