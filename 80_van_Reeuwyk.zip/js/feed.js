$(document).ready(() =>{

    $("#feedLink").addClass("active activeLine");

});
